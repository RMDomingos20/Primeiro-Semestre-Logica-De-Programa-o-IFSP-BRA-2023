#include <stdio.h>

int main(){
    
    int i, resp, resp1, resp2;
    int medi, smti, smtp, medp;
    
    
    printf ("Quantos alunos ha na turma: \n");
    scanf ("%d", &resp);
    
    for (i=0;i<resp;i+=1){
        
        printf ("%d_Criança idade: \n", i+1);
        scanf ("%d", &resp1);
        
        printf ("%d_Criança peso: \n", i+1);
        scanf ("%d", &resp2);
        
        smti += resp1;
        smtp += resp2;
        
    }
    
    medi = smti/resp;
    medp = smtp/resp;
    
    printf ("Somatoria das idades_____%d\n",smti);
    printf ("Media das idades_________%d\n",medi);
    printf ("Media de peso____________%dKG\n",medp);
    
    return 0;
}
