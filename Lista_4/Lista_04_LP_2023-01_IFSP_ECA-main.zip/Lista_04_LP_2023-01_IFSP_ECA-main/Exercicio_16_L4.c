#include <stdio.h>
#include <math.h>

int main(){
    
    long pA = 90000, pB = 200000;
    float crA = 0.03, crB = 0.015;
    int i=0;
    
    do{
        i+=1; 
        
        pA = pA +(pA *crA);
        pB = pB +(pB *crB);
        
        printf ("%lu A\t", pA);
        printf ("%lu B\n", pB);
        
    }while(pA<pB);
    printf ("\n%d anos necessarios para A ser maior ou igual a B", i);
    return 0; 
}
