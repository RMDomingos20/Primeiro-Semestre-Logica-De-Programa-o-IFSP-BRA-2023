#include <stdio.h>

int main(){
    
    int i, resp, res;
    
    for (i=-100;i<401;i+=1){
        
     printf ("\n%d", i);
        if (i<0){
            printf("-Valor_Negativo");
        }
        else {
             printf ("-Valor_Positivo");
        }
    }
    return 0;
}
