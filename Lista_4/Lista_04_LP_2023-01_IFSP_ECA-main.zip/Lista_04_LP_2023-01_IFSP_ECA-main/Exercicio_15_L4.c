#include <stdio.h>

int main(){
    
    int i;
    int func, resp; // entradas de resposta.
    int idh, idm, psh, psm;// entrada de dados idade e peso m e f.
    int sidh, sidm, spsh, spsm; //somatoria dos valores de idade e peso m e f .
    int qth, qtm; // somatoria quantidade de homens ou mulheres.
    float ath, atm, sath, satm; // entradas e somatoria da altura m e f.
    
    printf ("Quantos funcionario há na empresa:\n");
    scanf ("%d", &func);
    
    for (i=0;i<func;i+=1){
        
        printf ("Pressione (1) para masculino\nPressione (2) para feminino\n");
        scanf ("%d", &resp);
          
            switch (resp){
              
                case 1:
                
                    qth += 1;
                    printf ("\nme informe sua idade: ");
                    scanf ("%d", &idh);
                      
                    sidh += idh;
                      
                    printf ("\nMe informe seu peso: ");
                    scanf ("%d", &psh);
                      
                    spsh += psh;
                      
                    printf ("\nMe informe sua altura: ");
                    scanf ("%f", &ath);
                      
                    sath += ath;
                  
                    system ("clear");
                break;
              
                case 2:
                
                    qtm += 1;
                    printf ("\nme informe sua idade: ");
                    scanf ("%d", &idm);
                      
                    sidm += idm;
                      
                    printf ("\nMe informe seu peso: ");
                    scanf ("%d", &psm);
                      
                    spsm += psm;
                      
                    printf ("\nMe informe sua altura: ");
                    scanf ("%f", &atm);
                      
                    satm += atm;
                      
                    system ("clear");  
                    break;
                    
                default: 
                    system ("clear");
                    printf ("\nNao e valor valido\n");
                    i = i - 1;
                    break;
            }
    }
   
    printf ("quantia de funcionarios______________%d\n", func);
    printf ("quantidade de funcionarios homens____%d\n", qth);
    printf ("quantidade de funcionarios mulheres__%d\n", qtm);
    printf ("Idade media masculina________________%d anos\n", (sidh/qth));
    printf ("Idade media feminia__________________%d anos \n", (sidm/qtm));
    printf ("Altura media masculina_______________%.2fm\n", (sath/qth));
    printf ("Altura media feminina________________%.2fm\n", (satm/qtm));
    printf ("Peso medio masculino_________________%dkg\n", (spsh/qth));
    printf ("Peso medio feminino__________________%dkg\n", (spsm/qtm));
    
    return 0;
}
