#include <stdio.h>

int main(){
    
    int i, resp, m18;
    
    for (i = 0;i<10;i+=1){
    
        printf("%d* idade: \n", i+1);
        scanf ("%d", &resp);
        
        if (resp >= 18){
            m18 += 1;
        }
    }
    
    
    printf ("\nTotal de pessoas maiores de idade_______%d", m18);
    return 0;
}
