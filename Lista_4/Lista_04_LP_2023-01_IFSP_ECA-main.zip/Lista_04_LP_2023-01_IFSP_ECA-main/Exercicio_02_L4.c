#include <stdio.h>

int main(){
    
    int i;
    
    
    for (i=0;i<101;i+=1){
        
        printf ("%d\n", i);
    }
    
    return 0;
}
