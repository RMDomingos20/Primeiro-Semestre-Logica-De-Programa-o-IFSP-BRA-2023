#include <stdio.h>

int main(){
    
    int i, resp, res;
    
    for (i=5000;i>2;i-=1){
        
      res = i%2;

          if (res == 1){
              printf ("-%d", i);
              printf ("-impar\t");
          }
    }
 return 0;
}
