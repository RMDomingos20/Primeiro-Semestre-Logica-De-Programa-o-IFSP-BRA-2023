#include <stdio.h>

int main(){
    
    int i, resp, menor, maior;

    printf ("\n1_valor: ");
    scanf ("%d", &resp);
    
    menor = resp;
    maior = resp;
    
        for (i=1;i<100;i+=1){
           
            printf ("\n%d_valor: ", i+1);
            scanf ("%d", &resp);
           
            
            if (resp>maior){
                maior = resp;
            }
            if (resp<menor){
                menor = resp;
            }
       }
       
       printf ("\nMaior numero____%d", maior);
       printf ("\nMenor numero____%d", menor);
    return 0;
}
