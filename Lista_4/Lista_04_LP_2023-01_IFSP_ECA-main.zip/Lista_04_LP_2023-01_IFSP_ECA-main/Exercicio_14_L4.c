#include <stdio.h>

int main(){
    
    
    int i, resp;
    float Fa, Fb, Fc, Fd, Fe;
    float Fap, Fbp, Fcp, Fdp, Fep;
    float som;
    
    for (i=0;i<300;i+=1){
    
        printf("%d idade: ", i+1);
        scanf ("%d", &resp);
        
        if (resp > 0 && resp <= 15){
            Fa += 1;
        }
        if (resp > 15 && resp <= 30){
            Fb += 1;
        }
        if (resp > 30 && resp <= 45){
            Fc += 1;
        }
        if (resp > 45 && resp <= 60){
            Fd += 1;
        }
        if (resp > 60){
            Fe += 1;
        }
        if (resp > 0){
        som += 1;
        }
    }

    Fap = (Fa/som)*100, Fbp = (Fb/som)*100, Fcp = (Fc/som)*100, Fdp = (Fd/som)*100, Fep = (Fe/som)*100;
    
    printf ("\nPessoas totais = %.f", som);
    printf ("\nEntre 0 e 15 = %.2f%%", Fap);
    printf ("\nEntre 16 e 30 = %.2f%%", Fbp);
    printf ("\nEntre 31  e 45 = %.2f%%", Fcp);
    printf ("\nEntre 46 e 60 = %.2f%%", Fdp);
    printf ("\nEntre 60 = %.2f%%", Fep);

    return 0;
}
