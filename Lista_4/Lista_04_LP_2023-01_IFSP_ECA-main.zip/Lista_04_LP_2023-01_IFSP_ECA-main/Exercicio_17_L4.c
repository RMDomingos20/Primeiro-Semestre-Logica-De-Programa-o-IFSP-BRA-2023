/* Foi feita uma pesquisa entre os habitantes de uma região e coletados os dados
de altura e sexo (0=masc, 1=fem) das pessoas. 
Faça um programa que leia os dados de 50 pessoas e no final, informe:
- A maior e a menor altura encontrada
- A média de altura das mulheres
- A média de altura da população
- O percentual de homens na população*/
#include <stdio.h>
#include <math.h>

int main(){
    
    int resp1, i;
    int m, h;
    float resp2;
    float altm, alth, matp, matm, percentt;
    float Malt, malt;
    
    printf ("pessoa 1 pressione:\n(0)= masculino\t(1)= feminino\n");
    scanf ("%d", &resp1);
    
        switch (resp1){
            
            case 0:
            printf ("---selecionado Masculino---\n");
            printf ("Me informe a  Altura: ");
            scanf ("%f", &resp2);
            
            alth += resp2;
            h += 1; Malt = resp2, malt = resp2;
            break;
            
            case 1:
            printf ("---selecionado Feminino---\n");
            printf ("Me informe a  Altura: ");
            scanf ("%f", &resp2);
            
            altm += resp2;
            m += 1; Malt = resp2, malt = resp2;
            break;
            
            
            default: 
            printf ("Valor nao valido");
            break;
        }
        
    for (i=2;i<51;i++){
            
        printf ("\nPessoa %d pressione:\n(0)= masculino\t(1)= feminino\n", i);
        scanf ("%d", &resp1);
        
        switch (resp1){
            
            case 0:
            printf ("---selecionado Masculino---\n");
            printf ("Me informe a  Altura: ");
            scanf ("%f", &resp2);
            
                if (resp2>Malt){
                    Malt = resp2;
                }
                else if (resp2<malt){
                    malt = resp2;
                }
            
            alth += resp2;
            h += 1; 
            break;
            
            case 1:
            printf ("---selecionado Feminino---\n");
            printf ("Me informe a  Altura: ");
            scanf ("%f", &resp2);
            
                 if (resp2>Malt){
                    Malt = resp2;
                }
                else if (resp2<malt){
                    malt = resp2;
                }
            
            altm += resp2;
            m += 1; 
            break;
            
            
            default: 
            printf ("Valor nao valido");
            i -= 1;
            break;
        }
    }
    
    matp = (alth+altm)/(h+m); matm = altm/m; //media das alturas 
    percentt = ((h*100)/(h+m)); //percentuais 
        
    printf ("\n\n----Resultados----\n");
    printf ("Maior altura:%.2f\tMenor altura:%.2f\n", Malt, malt);
    printf ("Media altura mulheres: %.2f\n", matm);
    printf ("Media de altura total: %.2f\n", matp);
    printf ("Das %d pessoas, homens somam um percentual de %.2f%%", h+m, percentt);
    
    
}
