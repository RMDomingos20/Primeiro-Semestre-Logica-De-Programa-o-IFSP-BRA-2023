//Faça um algoritmo para calcular a soma de todos os números ímpares menores que 100
#include <stdio.h>
#include <math.h>

int main(){
    
   int i, rest, som;
   
   printf ("A soma de todos os impares de ]1,100[ são: ");
   
   for (i=0;i<100;i+=1){
       
       rest = i%2;
       
       if (rest == 1){
           
           som += i;
       }
   }
   printf ("%d", som);
   return 0;
}
