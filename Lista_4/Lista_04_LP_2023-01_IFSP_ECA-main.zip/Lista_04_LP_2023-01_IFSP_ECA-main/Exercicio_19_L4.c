/*  Num frigorífico existem 90 bois. Cada boi tem preso ao seu pescoço um cartão 
contendo seu número de identificação e seu peso. 
Faça um algoritmo que leia os dados do boi e imprima o peso do boi mais gordo.*/
#include <stdio.h>
#include <math.h>

int main(){
    
    int boi[90], i, resp;
    float peso[90], Mp;
    int Imp;
    
    printf ("Me informe o codigo numerico do 1 boi: ",i);
        scanf ("%d", &boi[0]);
        
        printf ("Me informe o peso deste boi: ");
        scanf ("%f", &peso[0]);
        
        Mp = peso[0];
    
    for (i=1;i<89;i++){
        
        printf ("\n\nMe informe o codigo numerico do %d boi: ",i+1);
        scanf ("%d", &boi[i]);
        
        printf ("Me informe o peso deste boi: ");
        scanf ("%f", &peso[i]);
        
        if (peso[i]>Mp){
            Imp = i;
        }
    }
    
    printf ("\nO boi mais gordo e %d\t", boi[Imp]);
    printf ("Pesando %.2fkg", peso[Imp]);
    
    
}
