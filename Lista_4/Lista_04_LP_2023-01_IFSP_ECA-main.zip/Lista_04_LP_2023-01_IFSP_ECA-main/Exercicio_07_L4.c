#include <stdio.h>

int main(){
    
    int i, x1, x2, x3;
    
    printf ("Me informe onde comecar a sequencia: ");
    scanf ("%d", &x1);
    printf ("Me informe onde terminar a sequencia: ");
    scanf ("%d", &x2);
    printf ("Distancia de um valor para outro: ");
    scanf ("%d", &x3);

    if (x1<x2){
    
        for (i=x1;i<x2+1;i+=x3){
            
            printf ("%d\t", i);
        }
    }
    //condição em caso o inicio for maior q o final XD
    else {
        for (i=x1;i>x2-1;i-=x3){
            
            printf ("%d\t", i);
        }
    }
    return 0;
}
