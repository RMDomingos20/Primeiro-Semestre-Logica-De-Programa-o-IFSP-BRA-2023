#include <stdio.h>
#include <math.h>

int main(){
    
    int i, z;
    
    for (i=1;i<11;i++){
        
        z+=i;
    }
    printf("A soma de todos os valores no intervalos [1, 10] é: %d", z);
}
