#include <stdio.h>

int main(){
    
    int i, resp, res;
    
    printf ("me informe um limite: ");
    scanf ("%d", &resp);
    
    for (i=0;i<resp+1;i+=1){
       
       res = i % 2;
            printf ("\n");
       if (res == 1){
            printf ("---valor impar_%d---", i);
       }
    }
   
    return 0;
}
