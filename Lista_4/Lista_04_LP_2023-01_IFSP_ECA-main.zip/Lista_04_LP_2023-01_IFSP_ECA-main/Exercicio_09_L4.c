#include <stdio.h>

int main(){
    
    int i, resp, smt, med;
    
    
    printf ("Me informe a idade dos alunos da turma");
    
    for (i = 0;i<40;i+=1){
    
        printf("%d* idade: \n", i+1);
        scanf ("%d", &resp);
        
        smt += resp;
    }
    
    med = smt/40;
    
    printf ("\nTotal somatoria de idade ______%d", smt);
    printf ("\nTotal media de idade___________%d", med);
    return 0;
}
