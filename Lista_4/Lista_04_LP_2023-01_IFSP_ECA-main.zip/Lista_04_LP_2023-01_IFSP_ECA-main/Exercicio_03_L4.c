#include <stdio.h>

int main(){
    
    int i, resp;
    
    printf ("Me informe um limite: ");
    scanf ("%d", &resp);
    
    
    for (i=0;i<resp+1;i+=1){
        if (i != resp){
        printf ("%d* PROCESSANDO\n", i);
        }
        else{
            printf ("%d* FINAL", i);
        }
    }
    
    return 0;
}
