# Lista_04_LP_2023-01_IFSP_ECA

1. Faça um programa para exibir na tela a palavra “Linguagem C” cem vezes.

2. Faça um programa para exibir todos os números ( de 1 a 100).

3. Faça um programa para exibir todos os números (de 1 a N), onde N é um número fornecido pelo usuário.

4. Faça um programa para exibir todos os números ímpares (de 1 a N), onde N é um número fornecido pelo usuário.

5. Faça um programa para exibir todos os números do intervalo [-100 e 400].

6. Faça um programa para exibir todos os números ímpares do intervalo [ 2 a 5000 ] em ordem decrescente.

7. Faça um programa para exibir uma seqüência de valores em ordem crescente. O programa deverá solicitar o primeiro valor, o último valor e o intervalo padrão entre eles; a seguir deverá exibir os valores.

8. Escreva um programa que receba a idade de dez pessoas, calcule e imprima a quantidade de pessoas maiores de idade (idade >= 18 anos).

9. Faça um programa que leia a idade de todos os alunos de uma turma de quarenta alunos, calcule e apresente:

- A soma das idades de todos os alunos;

- A média de idade dos alunos.

10.  Faça um programa para calcular e exibir a tabuada de um número qualquer (esse número deverá ser lido).

11.  Faça um programa que leia cem valores e no final, informe o maior e o menor valor digitado.

12. Cancelado.

13.  Faça um algoritmo que leia a idade e peso de todos os alunos de uma turma (a quantidade de aluno deverá ser lida), calcule e apresente:

        - A soma das idades de todos os alunos;
        - A média de idade dos alunos;
        - A média de peso dos alunos.

14.  Faça um algoritmo que receba a idade de trezentas pessoas, calcule e exiba a quantidade de pessoas em cada faixa etária; e a porcentagem de cada faixa etária em relação ao total de pessoas.

As faixas etárias são:

        1 a 15 anos
        16 a 30 anos
        31 a 45 anos
        46 a 60 anos
        igual a 61 anos
 
15.  Faça um algoritmo que leia a idade, sexo [utilize 1 – masculino e 2 – feminino], peso e altura de todos os funcionários de uma empresa, calcule e apresente:

        - A média de idade dos funcionários do sexo masculino;
        - A média de peso dos funcionários do sexo feminino;
        - A média de altura;
        - A média de peso;
        - A média de idade;
        - Total de funcionários do sexo masculino;
        - Total de funcionários do sexo feminino
                                           
*Obs.: A quantidade de funcionários deverá ser lida.

16.  Supondo que a população de um país A seja da ordem de 90.000 de habitantes com uma taxa anual de crescimento de 3% e que a população do país B seja, aproximadamente de 200.000 habitantes, com uma taxa anual de crescimento de 1,5%, faça um programa que calcule e escreva a quantidade de anos necessários para que a população do país A ultrapasse ou iguale a população do país B, mantida essas taxas de crescimento.


17.  Foi feita uma pesquisa entre os habitantes de uma região e coletados os dados de altura e sexo (0=masc, 1=fem) das pessoas. Faça um programa que leia os dados de 50 pessoas e no final, informe:

        - A maior e a menor altura encontrada
        - A média de altura das mulheres
        - A média de altura da população
        - O percentual de homens na população
 

18.  Faça um algoritmo para calcular e exibir a soma de todos os números da sequência [1 a 10].

 19.  Num frigorífico existem 90 bois. Cada boi tem preso ao seu pescoço um cartão contendo seu número de identificação e seu peso. Faça um algoritmo que leia os dados do boi e imprima o peso do boi mais gordo.

 20.  Faça um algoritmo para calcular a soma de todos os números ímpares menores que 100


Todos os exercicios estão disponiveis no meu github no seguinte link: https://github.com/RMDomingos20/Lista_04_LP_2023-01_IFSP_ECA/tree/f11dfcf4a864d95e3ed988df017d245c8a9353c6.
